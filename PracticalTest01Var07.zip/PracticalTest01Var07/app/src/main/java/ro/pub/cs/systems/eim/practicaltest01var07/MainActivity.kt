package ro.pub.cs.systems.eim.practicaltest01var07

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.widget.Button
import android.widget.EditText
import android.widget.Toast


class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var topLeftEditText = findViewById<EditText>(R.id.top_left_edit_text)
        var topRightEditText = findViewById<EditText>(R.id.top_right_edit_text)
        var botLeftEditText = findViewById<EditText>(R.id.bot_left_edit_text)
        var botRightEditText = findViewById<EditText>(R.id.bot_right_edit_text)

        val setButton = findViewById<Button>(R.id.set_button);

        setButton.setOnClickListener {
            val intent = Intent(this, PracticalTest01Var07SecondaryActivity::class.java)
            if (topLeftEditText.getText().toString().isEmpty() ||
                topRightEditText.getText().toString().isEmpty() ||
                botLeftEditText.getText().toString().isEmpty() ||
                botRightEditText.getText().toString().isEmpty()) {

                Toast.makeText(this@MainActivity, "Invalid Input",
                    Toast.LENGTH_LONG).show();
            } else {
                intent.putExtra("n1", Integer.valueOf(topLeftEditText.getText().toString()))
                intent.putExtra("n2", Integer.valueOf(topRightEditText.getText().toString()))
                intent.putExtra("n3", Integer.valueOf(botLeftEditText.getText().toString()))
                intent.putExtra("n4", Integer.valueOf(botRightEditText.getText().toString()))
                startActivity(intent)
            }
        }
    }
}