package ro.pub.cs.systems.eim.practicaltest01var07

import android.app.PendingIntent.getActivity
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class PracticalTest01Var07SecondaryActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_practical_test01_var07_secondary)

        var topLeftText = findViewById<TextView>(R.id.top_left_text)
        var topRightText = findViewById<TextView>(R.id.top_right_text)
        var botLeftText = findViewById<TextView>(R.id.bot_left_text)
        var botRightText = findViewById<TextView>(R.id.bot_right_text)

        var n1 = intent?.extras?.get("n1")
        var n2 = intent?.extras?.get("n2")
        var n3 = intent?.extras?.get("n3")
        var n4 = intent?.extras?.get("n4")

        topLeftText.setText(n1.toString())
        topRightText.setText(n2.toString())
        botLeftText.setText(n3.toString())
        botRightText.setText(n4.toString())

        val sumButton = findViewById<Button>(R.id.sum_button);
        val prodButton = findViewById<Button>(R.id.prod_button);

        sumButton.setOnClickListener {
            var sum = 0;
            sum += Integer.valueOf(topLeftText.getText().toString())
            sum += Integer.valueOf(topRightText.getText().toString())
            sum += Integer.valueOf(botLeftText.getText().toString())
            sum += Integer.valueOf(botRightText.getText().toString())
            Toast.makeText(this@PracticalTest01Var07SecondaryActivity, "Sum: " + sum,
                Toast.LENGTH_LONG).show();
        }

        prodButton.setOnClickListener {
            var prod = 1;
            prod *= Integer.valueOf(topLeftText.getText().toString())
            prod *= Integer.valueOf(topRightText.getText().toString())
            prod *= Integer.valueOf(botLeftText.getText().toString())
            prod *= Integer.valueOf(botRightText.getText().toString())
            Toast.makeText(this@PracticalTest01Var07SecondaryActivity, "Product: " + prod,
                Toast.LENGTH_LONG).show();
        }
    }
}